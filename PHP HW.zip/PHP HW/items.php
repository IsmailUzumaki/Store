<?php 
	require_once 'itemsfunction.php';
	
	$photos =array("<img src = 'kakashi.jpg' width='300' height='300'>",
				 "<img src = 'allmight.jpg' width='300' height='300'>",
				 "<img src = 'simondominic.jpg' width='300' height='300'>",
				 "<img src = 'mlazi.jpg' width='300' height='300'>",
				 "<img src = 'Pokemon.jpg' width='300' height='300'>",
				 "<img src = 'dragon.jpg' width='300' height='300'>",
				 "<img src = 'ich.jpg' width='300' height='300'>",
				 "<img src = 'spider.jpg' width='300' height='300'>",
				 "<img src = 'loco.jpg' width='300' height='300'>",
				 "<img src = 'beads.jpg' width='300' height='300'>",
				 
				 
				 
				 
				 
				 
				 
				 
				 );

	$items = [
		'1' => new Item(0,'Naruto Shippuden', 4.5,'T-Shirt','Watercolor T-Shirt of Kakashi Hatake, the coolest, most kickass ninja of the Hidden-leaf village. ',$photos[0]),
		'2' => new Item(1,'My Hero Academia', 12.70, 'T-Shirt','Black All Might T-Shirt. A true hero is one who overcomes lifes misfortunes',$photos[1]),		
		'3' => new Item(3,'Won & Only - EP',12.00,'Digital EP','Korean born rapper Simon Dominic has returned with an amazing EP',$photos[2]),
		'4' => new Item(4,'Mlazi Milano', 19.00, 'Digital Album','South African born rapper Okmalumkoolkat he is so cryptic and smart about his choice of words, bringing a balance between his style, flow and depth of his lines. Perhaps the best album of 2017.',$photos[3]),
		'5' => new Item(5,'Pokemon', 5.00, 'Key Chain','Size: 1 inch Diameter Design,  2.5 inch Chain and Ring',$photos[4]),
		'6' => new Item(6,'Dragonball Super', 5.00, 'Key Chain','Size: 1 inch Diameter Design,  2.5 inch Chain and Ring',$photos[5]),
		'7' => new Item(7,'Icha Icha Paradise', 20.00, 'Paperback book' ,'Best selling novel from Jiraya sensei. The novel is about a passionate love between a man and a woman',$photos[6]),
		'8' => new Item(8,'Spiderman: Clone Saga Epic 1', 22.00, 'Paperback Comic book','Spider-Mans clone is back  and the real Spidey is beside himself Peter thought his clone was long dead, but where has Ben Reilly been for the last five years? ',$photos[7]),
		'9' => new Item(9,'Bleached', 19.00, 'Digital Album','“Bleached” is the 1st album recorded by South Korean rapper Loco - 로꼬',$photos[8]),
		'10' => new Item(10,'Kimoyo Beads', 12.70, 'Accessory Item','Wakandas precious Kimoyo beads are at your hand, allowing access to Black Panthers secret communication field with this exquisite gunmetal bracelet by RockLove. A blue prime bead holds a lifetime of knowledge and illuminates in the dark.',$photos[9]),
		];
?>


