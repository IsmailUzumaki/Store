<?php

class Item {
	var $id;
	var $name;
	var $price;
	var $category;
	var $description;
	var $photo;

	
	function __construct($id,$name,$price,$category,$description,$photo) 
	{
		$this->id = $id;
		$this->name = $name;
		$this->price = $price;
		
		$this->category = $category;
		$this->description = $description;
		$this->image = $photo;
	}
	
	function get_id()
	{
		return $this->id;
	}
	function get_name() 
	{
		return $this->name;
	}
	function get_photo() 
	{
		return $this->image;
	}
	function get_price() 
	{
		return $this->price;
	}
	function get_category() 
	{
		return $this->category;
	}
	function get_description() 
	{
		return $this->description;
	}
		
	function takes_currrency($number)
	{
		$number = get_price();
		setlocale(LC_MONETARY,"en_US");
		echo money_format($number);
	}

	
	
	function get_select($max_items) 
	{
		$id = $this->get_name();
		$html = <<<EOT
			<label for="$id">$this->description</label>
			<select id="$id" name="$id">
EOT;

		for ($count = 0; $count <= $max_items; $count++)
		{
			$html .= <<<EOT
				<option value="$count">$count</option>
EOT;
		}
		$html .= '</select>';
		return $html;
	}
}
//function get_name() {return $this->description . 'Item';}
?>

