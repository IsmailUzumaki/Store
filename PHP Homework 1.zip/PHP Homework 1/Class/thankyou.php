<?php
if(($_POST['namep'])&& ($_POST['email_address']))
{}
else
{
header('Location: http://localhost/class/confirm.php');	
}
?>

<!DOCTYPE html>
<html>
	<head>
			<title> Groot </title>
			
	</head>
	<body>	
	<h1 style = "background-color: LightGray"> Thank you for your purchase </h1>
	</body>
</html>