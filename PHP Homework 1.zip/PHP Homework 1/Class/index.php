<?php
//declared data variables
$discountAmount = 0.00;
$total = 0.00;
$salesp = ' ';
$discountp = ' ';
//variable for number two
$two = 2;

//I want to check if the form has posted back and whether data was entered by the user for sales price, and discount percent
$isPostBack = false;
if(isset($_POST['submit'])){
	$isPostBack = true;
	$salesp = $_POST['salesPrice'];
	$discountp = $_POST['discount'];
}

$isValidPrice = true;
$isValidPercent = true;

//If there is data in the form when it posts back I want to check if the data entered is valid by that >0
if($isPostBack)
{
	
	$isValidPrice = is_numeric($salesp) && $salesp > 0.0;
	if($isValidPrice>0)
	{
		$salesp = $_POST['salesPrice'];
	}
	
	$isValidPercent = is_numeric($discountp) && $discountp > 0.0;
	if(($isValidPercent>0))
	{
		if($discountp < 101)
		{
			$discountp = $_POST['discount'];
		}
		else
		{
			$discountp = "Must be >0 or <100";
			
		}
		
	}
	
	if ($isValidPrice && $isValidPercent)
	{ 
	
		$discountAmount = $salesp* ($discountp/100);
		$total = $salesp - $discountAmount;	
		
	}//else DoNothing();
	
	
}//else DoNothing();
	
	
	// if the confirm button is pressed I want to ensure that data has been entered in
	if(isset($_POST['next'])){
	
	$salesp = $_POST['salesPrice'];
	$discountp = $_POST['discount'];
	
	}
	//else DoNothing();

?>	
	
<!DOCTYPE html>
<html>
	<head>
			<title> Groot </title>
			<link rel= "stylesheet" href = "default.css" type = "text/css"/>
	</head>
	<body>
		<h1 style = "background-color: LightGray"> Price Quotation </h1>
	
		<form action = "index.php" method = "post">
		<label for = "salesPrice"> Sales Price <div align = "center">$  </label>
		<input type = "text" id = "salesPrice" name = "salesPrice" value = "<?php if ($isValidPrice){echo number_format((float)$salesp,$two,'.','');} ?>" />
	<?php if(!$isValidPrice): ?>
		<span class= "error"> Invalid Value for Price</span>
	<?php endif; ?> </div>
	
		<br />
		<label for = "discount"> Discount Percent <div align = "center"> </label>
		<input type = "text" id = "discount" name = "discount" value = "<?php if ($isValidPercent){echo $discountp;} ?>" /> % 
	<?php if(!$isValidPercent): ?>
		<span class= "error"> Invalid Value for Percent</span>
	<?php endif; ?></div>
		<br />
	<?php if ($isValidPrice && $isValidPercent): ?>	
		<br/>
		Discount Price <div align = "center">$<?php print number_format((float)$discountAmount,$two,'.',''); ?> 
		</div>
		<br/>
		<br/>
		Total Price <div align = "center"> $<?php print number_format((float)$total,$two,'.',''); ?>
		</div>
	<?php endif; ?>	
		<br/>		
		<font color = "blue">Please Enter a Sales Price ,and Discount Percent and click Calculate
		</font>
		<br/>
		<div align = "center">

		<input type = "submit" name="submit" id="submit"  value = "Calculate"  /> 
	<?php if ($isValidPrice && $isValidPercent): ?>	
		<input type = "submit" formaction = "confirm.php" name = "next" id = "next"  value = "Confirm" />		
	<?php endif; ?>	
		
		
		</div>
	</form>
	</body>
</html>