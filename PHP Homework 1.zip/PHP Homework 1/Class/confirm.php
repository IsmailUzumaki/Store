<?php

//declared variables
	$discountAmount = 0.00;
	$total = 0.00;
	$sale = 0.00;
	$dis = 0.00;
	$name = ' ';
	$email = ' ';
	
/* 

if values for sales price and discount amount exist then calculations are to be made for the total
else redirect user to index.php

*/	
	if(is_numeric($_POST['salesPrice']) && is_numeric($_POST['discount']))
	{
	$sale = $_POST['salesPrice'];	
	
	$dis = $_POST['discount'];		
	
	
	$formatted_sale = number_format((float)$sale,2,'.','');
	$formatted_discount = number_format((float)$dis,2,'.','');
	
	$discountAmount = $sale* ($dis/100);
		$total = $sale - $discountAmount;

	$formatted_total = number_format((float)$total,2,'.','');
	}
	else
	{
		header('Location: http://localhost/class/index.php');
	}
		
	$isPostBack = false;
	if(isset($_POST['send']))
	{
	$isPostBack = true;
	$name = $_POST['namep'];
	$email = $_POST['email_address'];

	}
	
	$isValidName = true;
	$isValidEmail = true;

	
if($isPostBack)
{
	$isValidName = is_string($name);
	if($isValidName)
	{
		$name = $_POST['namep'];
	}
	
	$isValidEmail = is_string($email);
	if($isValidEmail)
	{
		$email = $_POST['email_address'];
	}
	
	
}

	
	?>

<!DOCTYPE html>	
<html>
	<head>
		<title>Groot</title>
		<link rel= "stylesheet" href = "default.css" type = "text/css"/>
	</head>
	<body>
	<h1 style = "background-color: LightGray"> Quotation Confirmation</h1>
	
	
		<br/>
		<form action = "confirm.php" method = "post" >
		<div align = "center">
	<?php echo 'Sales Price $'.$formatted_sale?>
		<br/>
		<br/>
	<?php echo 'Discount Price $'.$formatted_discount?>
		<br/>
		<br/>
	<?php echo 'Total Price $'.$formatted_total?>	
		<br/>
		<br/>
		
		<h2>Send Confirmation to</h2>
		
		<br/v>
		<label for = "namep"> Name:   </label>
		<input type = "namep" id = "namep" name = "namep" value = "<?php if ($isValidName){echo $name;} ?>"  />
		<br/>
	<?php if(!$isValidName): ?>
		<span class= "error"> Invalid entry for name</span>
	<?php endif; ?>
		<br/>
		<label for = "email_address"> Email Address: </label>
		<input type = "email_address" id = "email_address" name = "email_address" value = "<?php if ($isValidEmail){echo $email;} ?>" />
		<br/>
	<?php if(!$isValidEmail): ?>
		<span class= "error"> Invalid entry for email address</span>
	<?php endif; ?>

		<br/>
			
		<input type = "Submit" name = "send" id = "send" value = "Confirm" formaction = "thankyou.php" /> 
		<?php if (preg_match('/\bare\b/',$name)): ?>
		
		<?php endif;?>
		<input type = "Submit" formaction = "index.php" value = "Return" />
		</div>
		
		</form>
		<font color = "blue">Click the Send Quotation to send the quotation via email.
		</font>
		
		
		
	</body>
</html>
